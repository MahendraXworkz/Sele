# LambdaTest
# to execute test in the MAVEN right click on test mouse over Run Maven Commands... then click on test
# test will be executed
